<?php
   $name=$_POST['name'];
   $email=$_POST['email'];
   $mobile=$_POST['mobile'];
   $password=$_POST['password'];

   
   $conn=new mysqli('localhost:3308','root','','hospital');
   if($conn->connect_error){
	   
	  die('connection Failed :'.$conn->connect_error);
   }else{
	   $stmt=$conn->prepare("insert into registration(name,email,mobile,password)
	   values(?,?,?,?)");
	   $stmt->bind_param("ssis",$name,$email,$mobile,$password);
	   $stmt->execute();
	   $stmt=$conn->prepare("insert into login(email,password)
	   values(?,?)");
	   $stmt->bind_param("ss",$email,$password);
	   $stmt->execute();
	   echo "<script> 
			 alert('Resigration Success!!! ');
			 window.location.href='login.html';
			 </script>";
	   $stmt->close();
	   $conn->close();
	   
   }
   

?>